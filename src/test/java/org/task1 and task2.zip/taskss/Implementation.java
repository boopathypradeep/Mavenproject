package org.taskss;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Implementation extends BaseClass {
	
	@Test
	private void tc03() {
		launchBrowser();
		maximize();
		launchUrl("https://www.ebay.com/");
		implicitlyWait(10, TimeUnit.SECONDS);
	Ebay e=new Ebay();
WebElement search = e.getSearch();
BaseClass b=new BaseClass();
b.enterText(search, "electric guitar");
	WebElement btnSearch = e.getBtnSearch();
	b.btnClick(btnSearch);
	WebElement btnClick = e.getBtnClick();
	b.btnClick(btnClick);
	switchTOLastWindow();
	WebElement price = e.getPrice();
	String textss = b.getTextss(price);
	b.print(textss);
	
	}
	

}

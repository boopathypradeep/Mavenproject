package org.taskss;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Gmail extends BaseClass {
	@BeforeClass
	private void tc01() {
		launchBrowser();
		maximize();
		launchUrl("https://accounts.google.com/b/0/AddMailService");
		implicitlyWait(10, TimeUnit.SECONDS);

	}
	@Test
	private void tc02() {
		TaskGmail t=new TaskGmail();
		
		BaseClass b=new BaseClass();
		
		WebElement userName = t.getUserName();
		
		b.enterText(userName, "boopathypradeepr@gmail.com");
		WebElement btnNext = t.getBtnNext();
		b.btnClick(btnNext);
		WebElement passWord = t.getPassWord();
		b.btnClick(passWord);
		
		WebElement btnNext2 = t.getBtnNext2();
		b.btnClick(btnNext2);
		WebElement profileButton = t.getProfileButton();
		
		Assert.assertTrue(enabled(profileButton));
		
	}
}
